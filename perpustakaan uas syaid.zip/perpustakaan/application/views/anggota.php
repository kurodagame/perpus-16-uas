<div class="container">
<form action="welcome/tambahrekordanggota" method="post">
  <div class="form-group">
    <label for="nomor anggota">Nomor Anggota:</label>
  <textarea class="form-control" rows="5" id="nomor anggota" name="nomor anggota"></textarea>
  </div>
  <div class="form-group">
    <label for="nama anggota">Nama Anggota:</label>
  <textarea class="form-control" rows="5" id="nama anggota" name="nama anggota"></textarea>
  </div>
  <div class="form-group">
    <label for="alamat">Alamat:</label>
   <textarea class="form-control" rows="5" id="alamat" name="alamat"></textarea>
  </div>
  <div class="form-group">
    <label for="tanggal daftar">Tanggal Daftar:</label>
  <input type="datetime-local" class="form-control" id="tanggal daftar" name="tanggal daftar"></textarea>
  </div>
  <div class="form-group">
    <label for="tanggal kadaluarsa">Tanggal Kadaluarsa:</label>
  <input type="datetime-local" class="form-control" id="tanggal kadaluarsa" name="tanggal kadaluarsa"></textarea>
  </div>
  <button type="submit" class="btn btn-primary" name="bSimpan">Submit</button>
</form>
</div>