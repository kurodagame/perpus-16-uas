<div class="container">
  <!-- Brand/logo -->
  <a class="navbar-brand" href="#">
    <img src="<?= base_url();?>/img/syaid.jpg" alt="logo" style="width:300px;">
<form action="welcome/tambahrekordabout" method="post">
  <div class="form-group">
    <label for="nama pembuat">Nama Pembuat:</label>
  <textarea class="form-control" rows="5" id="nama pembuat" name="nama pembuat">Muhammad Syaid Abdul Malik</textarea>
  </div>
  <div class="form-group">
    <label for="npm pembuat">NPM Pembuat:</label>
  <textarea class="form-control" rows="5" id="npm pembuat" name="npm pembuat">1955201060</textarea>
  </div>
 </form>
</div>